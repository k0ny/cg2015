var Feature = require('./Feature.js');

Feature.inherits(Armadio, Feature);

function Armadio(feature) {
	Feature.call(this, feature);
}
Armadio.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Armadio.prototype.in_graph = true;
Armadio.prototype.in_2D_map = false;

Armadio.prototype.get3DModel = function() {

      var armadio = new THREE.Object3D();

      var legno = new THREE.MeshPhongMaterial( {color: 0x000000});
	  var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
      legno.map = texture;

      var colore = new THREE.MeshLambertMaterial({color : 0xffffff});
      var geometria = new THREE.BoxGeometry(1, 2.5, 0.7);

      var armadio1 = new THREE.Mesh( geometria, legno ) ;
      armadio1.position.x -= 1.02;

      var armadio2 = new THREE.Mesh( geometria, legno ) ;

      var armadio3 = new THREE.Mesh( geometria, legno ) ;
      armadio3.position.x += 1;

      function Maniglia() {

      var maniglia = new THREE.Object3D();
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
      
      var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02,0.7 ,32);
      var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);

      var appendino = new THREE.Mesh( appendino_geo, metal ) ;
      var braccio1 = new THREE.Mesh( braccio_geo, metal ) ;
      var braccio2 = new THREE.Mesh( braccio_geo, metal ) ;

      appendino.rotation.z-=Math.PI/2;
      appendino.position.y-=0.2;
      appendino.position.z+=0.45;


      braccio1.position.z+=0.45;
      braccio1.position.x+=0.25;
      braccio1.position.y-=0.1;
      braccio2.position.z+=0.45;
      braccio2.position.x-=0.25;
      braccio2.position.y-=0.1;
      maniglia.add(braccio1);
      maniglia.add(braccio2);
      maniglia.add(appendino);
      maniglia.rotation.z+=Math.PI/2;
      maniglia.rotation.y+=Math.PI/2;
      maniglia.position.x -= 0.18;
      maniglia.position.z -= 0.15;
      maniglia.position.y += 0.18;
      maniglia.scale.set(0.4,0.4,0.4);
      maniglia.rotation.y += Math.PI;
      maniglia.position.z += 0.48;
      maniglia.position.x += 0.7;
      return maniglia;
    }

      var sottocassetto = new THREE.Object3D();
      var g2 = new THREE.BoxGeometry(0.95, 0.1, 0.6);
      var sottocassetto = new THREE.Mesh(g2, colore);
      sottocassetto.position.z -= 0.01;
       sottocassetto.position.y -= 1.3;

      var sottocassetto2 = new THREE.Object3D();
      var g2 = new THREE.BoxGeometry(1.9, 0.1, 0.6);
      var sottocassetto2 = new THREE.Mesh(g2, colore);
      sottocassetto2.position.z -= 0.01;
      sottocassetto2.position.y -= 1.3;
      sottocassetto2.position.x += 0.5;
 
      armadio1.add(sottocassetto);
      armadio2.add(sottocassetto2);


    var maniglia1 = Maniglia();
    var maniglia2 = Maniglia();
    var maniglia3 = Maniglia();

      armadio1.add(maniglia1);
      armadio2.add(maniglia2);
      maniglia3.position.x -= 0.7;
      armadio3.add(maniglia3);

      armadio.add(armadio3);
      armadio.add(armadio2);
      armadio.add(armadio1);
      armadio.position.y += 1.25;

      armadio.scale.set(0.6, 0.7, 0.6)

      return armadio;
  }
  module.exports = Armadio;