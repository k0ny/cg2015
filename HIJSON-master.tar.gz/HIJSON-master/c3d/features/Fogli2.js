var Feature = require('./Feature.js');

Feature.inherits(Fogli2, Feature);

function Fogli2(feature) {
	Feature.call(this, feature);
}

Fogli2.prototype.style = {
  prefix: "fa",
  icon: "minus",
  zIndex: 3
};

Fogli2.prototype.in_graph = true;
Fogli2.prototype.in_2D_map = false;

Fogli2.prototype.get3DModel = function() {

	 var foglio=new THREE.Object3D();
   //foglio.rotation.x=Math.PI/2;

   // var fogli1=THREE.ImageUtils.loadTexture("../../assets/textures/referto1.jpg" )
   // var fogli2=THREE.ImageUtils.loadTexture("../../assets/textures/referto2.png" )


     var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
    var ka = 0.4;
    grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );

     var te1 = THREE.ImageUtils.loadTexture("assets/textures/referto1.jpg");
     var fogli1 = new THREE.MeshPhongMaterial( {color: 0x000000});
     fogli1.map = te1;

     var te2 = THREE.ImageUtils.loadTexture("assets/textures/referto2.png");
     var fogli2 = new THREE.MeshPhongMaterial( {color: 0x000000});
     fogli2.map = te2;

   var vetro = new THREE.MeshPhongMaterial( {color: 0x1c1c1c});
    vetro.transparent=true;
    vetro.opacity=0.4;
    vetro.side = THREE.DoubleSide;

   var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );

   var geometry2 = new THREE.BoxGeometry(0.6, 1, 0.002 );

   var material = new THREE.MeshLambertMaterial( {color: 0xffffff} );
   material.side = THREE.DoubleSide;

  var foglio1 = new THREE.Mesh(geometry2, fogli1);
  foglio1.rotation.x += Math.PI/2;

  foglio.add(foglio1);

  var foglio2 = new THREE.Mesh(geometry2, fogli2);
  foglio2.rotation.x += Math.PI/2;
  foglio2.rotation.y += 0.002;
  foglio2.rotation.z += Math.PI/3 -0.6;
  foglio2.position.x += 0.5;

    var penna = new THREE.Object3D();

    var altezza = 0.3;
    var gp = new THREE.CylinderGeometry(0.01, 0.01, altezza);
    var p = new THREE.Mesh(gp, vetro);
    penna.add(p);

    var gt = new THREE.CylinderGeometry(0.01, 0.0001, 0.03);
    var c = new THREE.Mesh(gt, grigio);
    c.position.y -= altezza/2 + 0.01;
    penna.add(c);

    var cil = new THREE.CylinderGeometry(0.001, 0.001, altezza);
    var b = new THREE.Mesh(cil, grigio);
    p.add(b);

    penna.position.x += 1;
    penna.position.y += 0.005;
    penna.rotation.x = Math.PI/2;
    penna.rotation.y += 1;

    foglio.add(penna);

   foglio.add(foglio2);
   foglio.scale.set(0.3, 0.3, 0.3)
  return foglio;
};

module.exports = Fogli2;