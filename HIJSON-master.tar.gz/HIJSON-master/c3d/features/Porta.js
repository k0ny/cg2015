var Feature = require('./Feature.js');

Feature.inherits(Porta, Feature);

function Porta(feature) {
	Feature.call(this, feature);
}
Porta.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Porta.prototype.in_graph = true;
Porta.prototype.in_2D_map = false;

Porta.prototype.get3DModel = function() {
	
	var porta = new THREE.Object3D();

	var legno = new THREE.MeshPhongMaterial( {color: 0x000000});
	var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
    legno.map = texture;
	
	var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );

	var tex = new THREE.MeshPhongMaterial( {color: 0x000000});
	var texture = THREE.ImageUtils.loadTexture("assets/textures/ns.jpg");
    tex.map = texture;
	//var spessore = new THREE.Mesh(new THREE.BoxGeometry(1.5,1,0.02), mat_nero);
	
	var anta = new THREE.Mesh(new THREE.BoxGeometry(0.5,2.1,0.05), legno);
    var lato1 = new THREE.Mesh(new THREE.BoxGeometry(0.1,2,0.25), legno);
    var lato2 = new THREE.Mesh(new THREE.BoxGeometry(0.1,2,0.25), legno);
   
  

   	var numero = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.03), metal);
   	numero.position.z += 0.0375;
    numero.position.x += 0.2;
    numero.position.y += 0.4;
    numero.rotation.z += Math.PI/2;

    var s = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.0001), tex);
    s.position.z += 0.02;
    numero.add(s);
    lato1.add(numero);

    var numero = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.03), metal);
   	numero.position.z -= 0.0375;
    numero.position.x = 0.2;
    numero.position.y = 0.4;
    numero.rotation.z -= Math.PI/2;

    var s = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.0001), tex);
    s.position.z -= 0.02;
    numero.add(s);
    lato1.add(numero);

    var sovrapporta = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.1,0.35), legno);
    sovrapporta.rotation.z+=Math.PI/2;
    lato1.position.x+=0.6;
    anta.position.x+=0.4;
    lato2.position.x-=0.4;

    sovrapporta.position.y+=0.95;
    sovrapporta.position.x+=0.1;
    porta.add(anta);
    porta.add(lato1);
    porta.add(lato2);
	
	porta.add(sovrapporta);
	porta.rotation.x+=Math.PI/2;
	porta.position.z+=1;
	porta.position.x+=0.3;


	var maniglia = new THREE.Object3D();
	var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
	
	var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02,0.7 ,32);
	var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);

	var appendino = new THREE.Mesh( appendino_geo, metal ) ;
	var braccio1 = new THREE.Mesh( braccio_geo, metal ) ;
	var braccio2 = new THREE.Mesh( braccio_geo, metal ) ;
	var appendino2 = new THREE.Mesh( appendino_geo, metal ) ;
	var braccio3 = new THREE.Mesh( braccio_geo, metal ) ;
	var braccio4 = new THREE.Mesh( braccio_geo, metal ) ;
	
	appendino.rotation.z-=Math.PI/2;
	appendino.position.y-=0.2;
	appendino.position.z+=0.45;


	appendino2.rotation.z-=Math.PI/2;
	appendino2.position.y+=0.2;
	appendino2.position.z+=0.45;

	braccio1.position.z+=0.45;
	braccio1.position.x+=0.25;
	braccio1.position.y-=0.1;
	braccio2.position.z+=0.45;
	braccio2.position.x-=0.25;
	braccio2.position.y-=0.1;

	braccio3.position.z+=0.45;
	braccio3.position.x+=0.25;
	braccio3.position.y+=0.1;
	braccio4.position.z+=0.45;
	braccio4.position.x-=0.25;
	braccio4.position.y+=0.1;
	
	maniglia.add(braccio1);
	maniglia.add(braccio2);
	maniglia.add(appendino);
	maniglia.add(braccio3);
	maniglia.add(braccio4);
	maniglia.add(appendino2);
	
	maniglia.rotation.z+=Math.PI/2;
	maniglia.rotation.y+=Math.PI/2;
    maniglia.position.x+=0.2;
    //maniglia.position.y-=1;
    maniglia.scale.set(0.4,0.4,0.4);

    porta.add(maniglia);
    porta.position.x += 0.1;
    
	return porta;
};




module.exports = Porta;