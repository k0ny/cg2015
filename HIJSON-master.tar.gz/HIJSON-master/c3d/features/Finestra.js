var Feature = require('./Feature.js');

Feature.inherits(Finestra, Feature);

function Finestra(feature) {
	Feature.call(this, feature);
}

Finestra.prototype.style =  {
							color: "#0000FF",
							zIndex: 7
    					};

Finestra.prototype.get3DModel = function() {

  var finestra = new THREE.Object3D();

  var legno = new THREE.MeshPhongMaterial( {color: 0x000000});
  var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
  legno.map = texture;
  
  var lato1 = new THREE.Mesh(new THREE.BoxGeometry(0.1,1.57,0.38), legno);
  var lato2 = new THREE.Mesh(new THREE.BoxGeometry(0.1,1.57,0.38), legno);
  var sovrapporta = new THREE.Mesh(new THREE.BoxGeometry(0.1,1.9,0.38), legno);
  var sottoporta = new THREE.Mesh(new THREE.BoxGeometry(0.1,1.9,0.38), legno);
  var divisore = new THREE.Mesh(new THREE.BoxGeometry(0.1,1.57,0.38), legno);
  sovrapporta.rotation.z+=Math.PI/2;
  sottoporta.rotation.z+=Math.PI/2;
  divisore.position.x += 0;
  lato1.position.x+=1;
  lato2.position.x-=1;
  divisore.position.y+=0.01;
  lato1.position.y+=0.01;
  lato2.position.y+=0.01;
  sovrapporta.position.y+=0.75;
  sottoporta.position.y-=0.73;
  finestra.add(lato1);
  finestra.add(lato2);
  finestra.add(divisore);
  finestra.add(sovrapporta);
  finestra.add(sottoporta);
  /*
  var light = new THREE.AmbientLight( 0x404040 );
  finestra.add(light);
*/
  var maniglia = new THREE.Object3D();
  var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
  
  var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02,0.7 ,32);
  var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);

  var appendino = new THREE.Mesh( appendino_geo, metal ) ;
  var braccio1 = new THREE.Mesh( braccio_geo, metal ) ;
  var braccio2 = new THREE.Mesh( braccio_geo, metal ) ;

  appendino.rotation.z-=Math.PI/2;
  appendino.position.y-=0.2;
  appendino.position.z+=0.45;


  braccio1.position.z+=0.45;
  braccio1.position.x+=0.25;
  braccio1.position.y-=0.1;
  braccio2.position.z+=0.45;
  braccio2.position.x-=0.25;
  braccio2.position.y-=0.1;
  maniglia.add(braccio1);
  maniglia.add(braccio2);
  maniglia.add(appendino);
  maniglia.rotation.z+=Math.PI/2;
  maniglia.rotation.y+=Math.PI/2;
  maniglia.position.x -= 0.18;
  maniglia.position.z -= 0.15;
  maniglia.position.y += 0.18;
  maniglia.scale.set(0.4,0.4,0.4);

    divisore.add(maniglia);



  var vetro = new THREE.MeshPhongMaterial( {color: 0x1c1c1c});
  vetro.transparent=true;
  vetro.opacity=0.4;
  vetro.side = THREE.DoubleSide;

  var superficie = new THREE.Mesh(new THREE.PlaneGeometry(2, 1.55), vetro);
  superficie.position.z+=0.0205;

//var materiale = new THREE.MeshLambertMaterial( {color: 0xeeeeee} );
	  var materiale = new THREE.MeshLambertMaterial( { color: 0xE0FFFF, shading: THREE.FlatShading } );
      var ka = 0.4;
      materiale.ambient.setRGB( materiale.color.r * ka, materiale.color.g * ka, materiale.color.b * ka );

  var vet = new THREE.Mesh(new THREE.BoxGeometry(1.38, 0.9, 0.36), materiale);
  vet.rotation.z = Math.PI/2;
  vet.position.x -= 1.37/2;
  vet.position.x += 0.35/2 +0.01 ;
  vet.position.y += 0.01;
   vet.position.z += 0;
  finestra.add(vet);

  var vet2 = new THREE.Mesh(new THREE.BoxGeometry(1.38, 0.9, 0.36), materiale);
  vet2.rotation.z = Math.PI/2;
  vet2.position.x -= 1.37/2;
  vet2.position.x += 0.35/2 +0.01 ;
  vet2.position.x += 1.38/2 + 0.35 - 0.04;
  vet2.position.y += 0.01;
  vet2.position.z += 0;
  finestra.add(vet2);

  finestra.add(superficie);
  finestra.rotation.x+=Math.PI/2;
  finestra.position.z+=0.7;
  finestra.position.x+=1;

	return finestra;
};

Finestra.prototype.in_graph = true;
Finestra.prototype.in_2D_map = false;

module.exports = Finestra;