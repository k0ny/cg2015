var Feature = require('./Feature.js');

Feature.inherits(Pvc, Feature);

function Pvc(feature) {
	Feature.call(this, feature);
};

Pvc.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
};

Pvc.prototype.in_graph = true;

Pvc.prototype.in_2D_map = false;

Pvc.prototype.get3DModel = function() {
	var pavimento = new THREE.Object3D();

	var lato1 = 7.5;
	var lato2 = 30;
	 
	var texture1 = THREE.ImageUtils.loadTexture("assets/textures/scacchi.jpg");//public/assets/textures/marmo.jpg");
    texture1.wrapS = THREE.RepeatWrapping;
    texture1.wrapT = THREE.RepeatWrapping;
    var marmo = new THREE.MeshPhongMaterial();
    marmo.map = texture1;
	marmo.map.repeat.set(lato1, lato2);
    var piastrelle = new THREE.Mesh(new THREE.BoxGeometry(lato1, 0.05, lato2), marmo);
    piastrelle.rotation.x+=Math.PI/2;
    pavimento.add(piastrelle);

    var light = new THREE.AmbientLight( 0x404040 ); // soft white light
	pavimento.add( light );

	var light2 = new THREE.AmbientLight( 0x404040 ); // soft white light
	pavimento.add( light2 );
	
	return pavimento;
};

module.exports = Pvc;