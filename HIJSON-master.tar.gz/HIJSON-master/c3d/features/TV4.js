var Feature = require('./Feature.js');

Feature.inherits(TV4, Feature);

function TV4(feature) {
	Feature.call(this, feature);
}

TV4.prototype.style = {
			    			prefix: "fa",
	    					icon: "medkit",
	    					zIndex: 3
						};

TV4.prototype.in_graph = true;

TV4.prototype.in_2D_map = false;

TV4.prototype.get3DModel = function() {


     var gray_material = new THREE.MeshLambertMaterial({color : 0xa9a9a9});
      var black_material = new THREE.MeshLambertMaterial({color : 0x000000});


      //create a fake object
      var screen = new THREE.Object3D( );
      var dettaglio = 1;
      
      screen = createScreen();

      screen.rotation.x = Math.PI/2;
      screen.rotation.z = Math.PI;
      screen.position.y = 1;

      screen.scale.set(1, 1 , 1 );

      function createScreen(){

           //var black = new THREE.MeshLambertMaterial({color : 0x000000});
             var black = new THREE.MeshLambertMaterial( { color: 0x000000, shading: THREE.FlatShading } );
              var ka = 0.4;
              black.ambient.setRGB( black.color.r * ka, black.color.g * ka, black.color.b * ka );

            var tex = new THREE.MeshPhongMaterial( {color: 0xffffff});
            var texture = THREE.ImageUtils.loadTexture("assets/textures/radiografia2.jpg");
            tex.map = texture;

            var screen_geometry = new THREE.BoxGeometry( 0.8 , 0.01 , 0.4);
            var screen = new THREE.Mesh(screen_geometry, tex);
            screen.position.y = 0.01/2;

            var screenRam1_geometry = new THREE.BoxGeometry( 0.9 , 0.02 , 0.03 );
            var screenRam1 = new THREE.Mesh(screenRam1_geometry,black);
            screenRam1.position.z = -0.2-0.03/2;
            screen.add(screenRam1);

            var screenRam2_geometry = new THREE.BoxGeometry( 0.9 , 0.02 , 0.04 );
            var screenRam2 = new THREE.Mesh(screenRam2_geometry,black);
            screenRam2.position.z = 0.2+0.02;
            screen.add(screenRam2);

            var screenRam3_geometry = new THREE.BoxGeometry( 0.1/2 , 0.02 , 0.4 );
            var screenRam3a = new THREE.Mesh(screenRam3_geometry,black);
            var screenRam3b = new THREE.Mesh(screenRam3_geometry,black);
            screenRam3a.position.x = 0.4 + 0.1/4;
            screenRam3b.position.x = -0.4 - 0.1/4;

            screen.add(screenRam3a);
            screen.add(screenRam3b);

            var screenRam4_geometry = new THREE.BoxGeometry( 0.9 , 0.001 , 0.4 );
            var screenRam4 =new THREE.Mesh(screenRam4_geometry, black);
            screenRam4.position.y = -0.01/2;
            screen.add(screenRam4);


            screen.scale.set(0.1, 0.5, 0.5);
            return screen;
      };

    	screen.name = this.id;
	screen.feature = this;
	var model = Feature.packageModel(screen);
	return model;
};

module.exports = TV4;