var Feature = require('./Feature.js');

Feature.inherits(Doccia, Feature);

function Doccia(feature) {
	Feature.call(this, feature);
}
Doccia.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Doccia.prototype.in_graph = true;
Doccia.prototype.in_2D_map = false;

Doccia.prototype.get3DModel = function() {

      var doccia = new THREE.Object3D();
      var rubinetto = new THREE.Object3D();
      var sedia = new THREE.Object3D();
      var comandi = new THREE.Object3D();

      //Parametri
      var lato1 = 6;
      var lato2 = 7;
      var altezza = 3;

      //Materiali
      var manopole = new THREE.MeshPhongMaterial( {color: 0xdcdcdc} );
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );

      var comma = THREE.ImageUtils.loadTexture("../../assets/textures/comm.jpg" )
      var comm = new THREE.MeshPhongMaterial( {color: 0x000000});
      comm.map = comma;

       var t = THREE.ImageUtils.loadTexture("../../assets/textures/met.jpg" )
      var met = new THREE.MeshPhongMaterial( {color: 0x000000});
      met.map = t;

       var t2 = THREE.ImageUtils.loadTexture("../../assets/textures/met2.jpg" )
      var met2 = new THREE.MeshPhongMaterial( {color: 0x000000});
      met2.map = t2;

      var vetro = new THREE.MeshPhongMaterial( {color: 0xccffff});
      vetro.transparent=true;
      vetro.opacity=0.5;
      vetro.side = THREE.DoubleSide;

      var mat_bianco = new THREE.MeshPhongMaterial( {color: 0xffffff});
      var rosso = new THREE.MeshLambertMaterial( { color: 0xFF3636, shading: THREE.FlatShading } );
      var ka = 0.4;

      rosso.ambient.setRGB( rosso.color.r * ka, rosso.color.g * ka, rosso.color.b * ka );
      var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
      var ka = 0.4;
      grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );

      var blu = new THREE.MeshLambertMaterial( { color: 0x007FFF, shading: THREE.FlatShading } );
      var ka = 0.4;
      blu.ambient.setRGB( blu.color.r * ka, blu.color.g * ka, blu.color.b * ka );

      //Forme 
      var lastra = new THREE.Mesh(new THREE.BoxGeometry(2, altezza, 0.05), vetro);
      lastra.position.z-=lato2/2-1.5 + 2;
      lastra.position.x -= 2 ;
      lastra.position.y+=altezza/2;
      doccia.add(lastra);

      var lastr2 = new THREE.Mesh(new THREE.BoxGeometry(2, altezza, 0.05), vetro);
      lastr2.position.z -= lato2/2-1.5 + 1;
      lastr2.position.x -= 2 - 1 ;
      lastr2.position.y += altezza/2;
      lastr2.rotation.y += Math.PI/2;

      doccia.add(lastr2);

      //piastra ceracmica
      var p = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 0.2), metal);
      p.position.z-=lato2/2 - 0.52;
      p.position.x-=2;
      //p.position.y+=altezza/2;
      p.rotation.x += Math.PI/2;
      doccia.add(p);
      
      var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);
      var braccio1 = new THREE.Mesh( braccio_geo, metal ) ;
      braccio1.position.z+=0.45;
      braccio1.position.x+=0.9;
      braccio1.position.y-=0.3;
      var braccio2 = new THREE.Mesh( braccio_geo, metal ) ;
      braccio2.position.z+=0.45;
      braccio2.position.x-=0.9;
      braccio2.position.y-=0.3;

      var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02, 2 ,32);
      var appendino = new THREE.Mesh( appendino_geo, metal ) ;
      appendino.rotation.z-=Math.PI/2;
      appendino.position.y-=0.2;
      appendino.position.z+=0.45;


      var tubo_geo = new THREE.CylinderGeometry( 0.03, 0.03, 0.5 ,32);
      var tubo = new THREE.Mesh( tubo_geo, met ) ;
      tubo.rotation.x+=Math.PI/2;
      tubo.rotation.z+=Math.PI/2;
      tubo.position.y+=2;

      var toro_geo = new THREE.TorusGeometry(0.05, 0.03, 16, 32, Math.PI/2,true);
      var toro = new THREE.Mesh( toro_geo, met ) ;
      toro.position.y+=1.95;
      toro.position.x+=0.25;

      var alt = 0.15;
      var bocchettone_geo = new THREE.CylinderGeometry( 0.03, 0.1, alt ,32);
      var bocchettone = new THREE.Mesh( bocchettone_geo, met ) ;

      var bocchettone_g = new THREE.CylinderGeometry( 0.1, 0.1, 0.001 ,32);
      var bocc = new THREE.Mesh( bocchettone_g, met2 ) ;
      bocchettone.add(bocc);
      bocc.position.y -= alt/2;


      rubinetto.add(tubo);
      rubinetto.add(toro);
      rubinetto.add(bocchettone);
      bocchettone.position.y+=1.93;
      bocchettone.position.x+=0.28;

      doccia.add(rubinetto);
      rubinetto.position.x-=3;
      rubinetto.position.z-=3;
      rubinetto.position.y+=0.7;      
    
      var cylinderGeometry1 = new THREE.CylinderGeometry(0.001,0.001,0.04,80);
      var cylinderMaterial = new THREE.MeshLambertMaterial({color: 0xffffff});
      var c0 = new THREE.Mesh(cylinderGeometry1,cylinderMaterial);
      c0.rotation.z=Math.PI/2;
      c0.scale.set(3, 3, 3 );     
      c0.position.y += 0.004;

      var c2 = new THREE.Mesh(cylinderGeometry1,cylinderMaterial);
      c2.rotation.x=Math.PI/2;
      c2.scale.set(3, 3, 3 );
      c2.position.y += 0.004;
      
      var c3 = new THREE.Mesh(cylinderGeometry1,cylinderMaterial);
      c3.rotation.z=Math.PI/2;
      c3.rotation.y=Math.PI/4;
      c3.scale.set(3, 3, 3 );
      c3.position.y += 0.004;
      
      var c4 = new THREE.Mesh(cylinderGeometry1,cylinderMaterial);
      c4.rotation.z = Math.PI/2;
      c4.rotation.y =- Math.PI/4;
      c4.scale.set(3, 3, 3 );
      c4.position.y += 0.004;

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.06,0.06,0.01,80);
      var cylinderMaterial = new THREE.MeshLambertMaterial({color: 0x000000});
      var maniglia = new THREE.Mesh(cylinderGeometry1,cylinderMaterial);

      ////maniglia.position.z -= 0.5;
     // maniglia.position.y -= 0.5;
      maniglia.position.set(-2 , 0.52 /2 - 0.16, -lato2/2 + 0.5 );
      
      
      maniglia.add(c0);
      maniglia.add(c2);
      maniglia.add(c3);
      maniglia.add(c4);
      //c0.position.z += 0.3;

      //comandi
      var cylinderGeometry1 = new THREE.CylinderGeometry(0.03,0.03,0.1,80);
      var comando1 = new THREE.Mesh(cylinderGeometry1, grigio);
      comando1.position.set(-0.14,1,-0.20);
      comandi.add(comando1);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.01,0.01,0.04,80);
      var comando1e = new THREE.Mesh(cylinderGeometry1, rosso);
      comando1e.position.set(-0.14,1.04,-0.20);
      comandi.add(comando1e);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.03,0.03,0.1,80);
      var comando2 = new THREE.Mesh(cylinderGeometry1, grigio);
      comando2.position.set(-0.14,1,0.20);
      comandi.add(comando2);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.01,0.01,0.04,80);
      var comando2e = new THREE.Mesh(cylinderGeometry1, blu);
      comando2e.position.set(-0.14, 1.04, 0.20);
      comandi.add(comando2e);

      var geometria = new THREE.BoxGeometry(0.8, 0.2, 0.02);
      var base = new THREE.Mesh(geometria, metal);
      base.rotation.x += Math.PI/2;
      base.rotation.z += Math.PI/2;
      base.position.y += 0.95;
      base.position.x -= 0.1;
      comandi.add(base);

      var geometria = new THREE.BoxGeometry(0.8, 0.2, 0.02);
      var base2 = new THREE.Mesh(geometria, comm);
      base2.rotation.x += Math.PI/2;
      base2.rotation.z += Math.PI/2;
      base2.position.y += 0.95;
      base2.position.x -= 0.3 ;

      comandi.add(base2);



      comandi.rotation.z -= Math.PI/2;
      comandi.position.set(-3.8, 1.6, -3);
      doccia.add(maniglia);
      doccia.add(comandi);
      doccia.rotation.x+=Math.PI/2;
      doccia.scale.set(0.4, 0.8, 0.4);

      return doccia;
  }

module.exports = Doccia;