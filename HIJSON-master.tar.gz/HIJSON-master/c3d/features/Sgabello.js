var Feature = require('./Feature.js');

Feature.inherits(Sgabello, Feature);

function Sgabello(feature) {
	Feature.call(this, feature);
};

Sgabello.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
};

Sgabello.prototype.in_graph = true;

Sgabello.prototype.in_2D_map = false;

Sgabello.prototype.get3DModel = function() {
   var tavolino = new THREE.Object3D();

   var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
    var ka = 0.4;
    grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );

    var panna = new THREE.MeshLambertMaterial( { color: 0xC2B280} );
    

  var legno = new THREE.MeshPhongMaterial( {color: 0xffffff} );
  //var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
  //legno.map = texture;
  //legno.side = THREE.DoubleSide;

  var tavolino_geo = new THREE.CylinderGeometry( 0.6, 0.6, 0.3 ,32);
  var piano1 = new THREE.Mesh( tavolino_geo, panna ) ;
  tavolino.position.z += 0.3;

  var tavolino_g = new THREE.TorusGeometry( 1, 2, 8, 6, 10 );
  var piano = new THREE.Mesh( tavolino_g, legno ) ;
  piano.rotation.x += Math.PI/2;
  //tavolino.position.z += 0.3;
 // tavolino.add(piano);

  var altezza = 1.5;
  var zampa_geo = new THREE.CylinderGeometry( 0.05, 0.05, altezza ,32);
  zampa = new THREE.Mesh(zampa_geo, legno);
  zampa.position.y -= altezza/2;

  var base_geo = new THREE.CylinderGeometry( 0.05, 0.5, 0.1 ,32);
  base = new THREE.Mesh(base_geo, grigio);
  base.position.y -= altezza/2;

  zampa.add(base);

  tavolino.add(zampa);
  tavolino.add(piano1);
  tavolino.rotation.x+=Math.PI/2;
  tavolino.position.z+=0.5;
  tavolino.scale.set(0.5,0.5,0.5);

    var detail = 1;
    var geometriaLevaCorta = new THREE.CylinderGeometry( 0.0045 , 0.0045 , 0.07 , Math.round(32*detail) );
    var geometriaLevaLunga = new THREE.CylinderGeometry( 0.0045 , 0.0045 , 0.09 , Math.round(32*detail) );
    var geometriaManicoLeva = new THREE.CylinderGeometry( 0.007 , 0.005 , 0.06 , Math.round(32*detail) );
    var levaLunga = new THREE.Mesh( geometriaLevaLunga , grigio );
    var levaCorta = new THREE.Mesh( geometriaLevaCorta , legno );
    var manicoLeva1 = new THREE.Mesh( geometriaManicoLeva , legno );

    levaLunga.add(manicoLeva1);
    levaLunga.rotation.x = Math.PI/2;
    levaLunga.position.z = 0.035 + 0.045;
    levaLunga.position.x = 0;
    levaCorta.rotation.x =-Math.PI*80/180;
    levaCorta.position.z =-0.035 - 0.035;
    levaCorta.position.x = 0.08;
    manicoLeva1.position.y  = 0.045 + 0.03;
    levaLunga.scale.set(4, 5, 4);
    levaLunga.position.y += 0.5;
    levaLunga.rotation.x += Math.PI/2 - 4;
    levaLunga.rotation.y += Math.PI/2
    zampa.add(levaLunga);
    
    tavolino.scale.set(0.3, 0.3, 0.3);
    return tavolino;
};

module.exports = Sgabello;