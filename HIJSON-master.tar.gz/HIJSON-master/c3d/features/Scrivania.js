var Feature = require('./Feature.js');

Feature.inherits(Scrivania, Feature);

function Scrivania(feature) {
    Feature.call(this, feature);
}

Scrivania.prototype.style = {
                            prefix: "fa",
                            icon: "minus",
                            zIndex: 3
                        };

Scrivania.prototype.in_graph = true;
Scrivania.prototype.in_2D_map = false;

Scrivania.prototype.get3DModel = function() {

	  var geometry = new THREE.BoxGeometry( 3, 1, 0.6 );
    var materialBase = new THREE.MeshLambertMaterial( {color: 0xffffff} ); 
    var material = new THREE.MeshLambertMaterial( { color: 0xffffff, shading: THREE.FlatShading } );
    var ka = 0.4;
    material.ambient.setRGB( material.color.r * ka, material.color.g * ka, material.color.b * ka );
    
    var legno = new THREE.MeshPhongMaterial( {color: 0xF0DC82});
    var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    legno.map = texture;

    var scrivania = creaScrivania ();
    scrivania.scale.set(0.5, 0.5, 0.5 );

    function creaScrivania () {

      var scrivania = new THREE.Object3D();

      var base = creaBase();
      scrivania.add(base);

      var a = creaA();
      scrivania.add(a);

      var p = creaProlunga();
      scrivania.add(p);

   var men = new THREE.Object3D();

      var rectShape = new THREE.Shape();
      rectShape.moveTo( 0, 0 );
      rectShape.lineTo( 2.8, 0 );
      rectShape.lineTo( 2.8 + 1.5 + 0.2, 1);
      rectShape.lineTo( 2.8 + 0.7 + 0.2 , 2.2 );
      rectShape.lineTo( 2.5, 1.5);
      rectShape.lineTo( 0, 1.5);
      rectShape.lineTo( 0, 0);

      var extrudeSettings = { amount: 0.001, bevelEnabled: true, bevelSegments: 8, steps: 2, bevelSize: 0.1, bevelThickness: 0.05 };

      var geometry = new THREE.ExtrudeGeometry( rectShape, extrudeSettings );
      var mesh = new THREE.Mesh( geometry, legno );
      mesh.position.x = (-4.11 );
      mesh.position.y = (0.55 );
      mesh.position.z = (-0.8 );
      mesh.rotation.x += Math.PI/2;
      mesh.rotation.z += Math.PI - 0.58;
      mesh.rotation.y += Math.PI;
      mesh.scale.set(0.9, 0.9, 0.9);

      scrivania.add(mesh);

      var geometriaCilindroDx = new THREE.CylinderGeometry( 0.5, 0.5, 1, 32 );
      var cilindroDx = new THREE.Mesh( geometriaCilindroDx, materialBase );
      cilindroDx.position.x = (1.5);
      scrivania.add(cilindroDx);

//cilindro destro sovrastante
      var geometriaCilindroDx2 = new THREE.CylinderGeometry( 0.5, 0.5, 1, 32 );
      var cilindroDx2 = new THREE.Mesh( geometriaCilindroDx2, materialBase );
      cilindroDx2.position.x = (1.5);
      cilindroDx2.position.y = (1);
      cilindroDx2.position.z = (0.25);
      scrivania.add(cilindroDx2);

      var geometriaCilindroSx = new THREE.CylinderGeometry( 0.5, 0.5, 1, 32 );
      var cilindroSx = new THREE.Mesh( geometriaCilindroSx, materialBase );
      cilindroSx.position.x = (-1.5);
      scrivania.add(cilindroSx);

      return scrivania;
    }

    function creaBase() { 
      var geometria = new THREE.BoxGeometry(3, 1, 1);
      var base = new THREE.Mesh( geometria, materialBase);
      
      /*var light = new THREE.PointLight( 0xDF73FF, 1, 50 );
      light.position.set( 0, 0, 1);
      base.add( light );

     /* var light2 = new THREE.PointLight( 0xCCCCFF, 1, 100 );
      light.position.set( -1, 0, 1);
      base.add( light2 );
*/
      return base;
    }

    function creaProlunga() { 
      var geometriaP = new THREE.BoxGeometry(1.5, 1, 1);
      var p = new THREE.Mesh( geometriaP, materialBase);

      var geometriaCilindroSx = new THREE.CylinderGeometry( 0.5, 0.5, 1, 32 );
      var cilindroSx = new THREE.Mesh( geometriaCilindroSx, materialBase );
      cilindroSx.position.x = (-0.75);
      p.add(cilindroSx);

      

      p.position.x = (-1.5 -0.75);
      p.position.z = (-0.5);
      p.rotation.y -= Math.PI/6 + 0.05;
      return p;
    }

//A è il pezzo grosso posizionato sopra la base a destra
    function creaA() {
      var geometria = new THREE.BoxGeometry(1.6, 1, 0.3);
      var a = new THREE.Mesh( geometria, materialBase);
      a.position.x = (1 - 0.3);
      a.position.y = (1);
      a.position.z = (0.6);

      
      return a;
    }

   	scrivania.name = this.id;
    scrivania.feature = this;
    var model = Feature.packageModel(scrivania);
    return model;
};

module.exports = Scrivania;