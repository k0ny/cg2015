var Feature = require('./Feature.js');

Feature.inherits(Computer, Feature);

function Computer(feature) {
  Feature.call(this, feature);
}

Computer.prototype.style = {
  prefix: "fa",
  icon: "minus",
  zIndex: 3
};

Computer.prototype.in_graph = true;
Computer.prototype.in_2D_map = false;

Computer.prototype.get3DModel = function() {

var nero = new THREE.MeshLambertMaterial( { color: 0x000000, shading: THREE.FlatShading } );
      var ka = 0.4;
      nero.ambient.setRGB( nero.color.r * ka, nero.color.g * ka, nero.color.b * ka );
      var gray_material = new THREE.MeshLambertMaterial({color : 0xa9a9a9});
      var black_material = new THREE.MeshLambertMaterial({color : 0x000000});
      var bianco = new THREE.MeshLambertMaterial( { color: 0xffffff, shading: THREE.FlatShading } );
      var ka = 0.4;
      bianco.ambient.setRGB( bianco.color.r * ka, bianco.color.g * ka, bianco.color.b * ka );
      var tex = new THREE.MeshPhongMaterial( {color: 0x000000});
      var texture = THREE.ImageUtils.loadTexture("assets/textures/case.jpg");
      tex.map = texture;
////INIZIO
      
      var altezza = 1.2;
      var base = 0.5;
      var prof = 1;
      var geometria = new THREE.BoxGeometry(base, altezza, prof);
      var pc = new THREE.Object3D();
      var ca = new THREE.Mesh(geometria, nero);
      ca.position.set(base/2, altezza/2, prof/2);

      var g = new THREE.BoxGeometry(base, altezza, 0.01);
      var c = new THREE.Mesh(g, tex);
      //var c = new THREE.Mesh(g, nero);
      c.position.set(0, 0, prof/2 + 0.01);

      ca.add(c);
      pc.add(ca);
      pc.scale.set(0.4, 0.4, 0.4);
      return pc


}
module.exports = Computer;