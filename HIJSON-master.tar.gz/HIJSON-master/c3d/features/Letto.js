var Feature = require('./Feature.js');

Feature.inherits(Letto, Feature);

function Letto(feature) {
	Feature.call(this, feature);
}

Letto.prototype.style =  {
							color: "#0000FF",
							zIndex: 7
    					};

Letto.prototype.get3DModel = function() {

	  var letto = new THREE.Object3D( );
	  

//COLORS AND MATERIALS 

      var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
      var ka = 0.4;
      grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );
 
      var grigioMetallico = new THREE.MeshLambertMaterial( { color: 0xC0C0C0, shading: THREE.FlatShading } );
      var ka = 0.4;
      grigioMetallico.ambient.setRGB( grigioMetallico.color.r * ka, grigioMetallico.color.g * ka, grigioMetallico.color.b * ka );
      var detail= 0.5;

       var c = new THREE.MeshLambertMaterial( { color: 0xE52B50, shading: THREE.FlatShading } );
      var ka = 0.4;
      c.ambient.setRGB( c.color.r * ka, c.color.g * ka, c.color.b * ka );
 
      var c1 = new THREE.MeshLambertMaterial( { color: 0x7FFF00, shading: THREE.FlatShading } );
      var ka = 0.4;
      c1.ambient.setRGB( c1.color.r * ka, c1.color.g * ka, c1.color.b * ka );

      letto.scale.set(0.08,0.08,0.08);
      var materasso = creaMaterasso()
      materasso.position.y = 2 + 8;
      letto.add( materasso);

//Shapes

      var bedBase_geometry = new THREE.BoxGeometry( 32 , 2 , 16 )
      var bedBase_material = new THREE.MeshLambertMaterial({color : 0x2BC066});
      var bedBase = new THREE.Mesh(bedBase_geometry, grigioMetallico);
      bedBase.position.y = 0.5 + 7
      letto.add( bedBase );

      var bedBase2_geometry = new THREE.BoxGeometry( 32 , 0.8 , 10 )
      var bedBase2_material = new THREE.MeshLambertMaterial({color : 0x2BC066});
      var bedBase2 = new THREE.Mesh(bedBase2_geometry, grigioMetallico);
      bedBase2.position.y = 0.5 + 5.5;
      letto.add( bedBase2 );

      var bedBase3_geometry = new THREE.BoxGeometry( 10 , 0.5 , 10 )
      var bedBase3_material = new THREE.MeshLambertMaterial({color : 0x2BC066});
      var bedBase3 = new THREE.Mesh(bedBase3_geometry, grigioMetallico);
      bedBase3.position.y = 0.5 + 6;
      letto.add( bedBase3 );

      var bedBase4_geometry = new THREE.BoxGeometry( 26 , 0.8 , 12 )
      var bedBase4_material = new THREE.MeshLambertMaterial({color : 0x2BC066});
      var bedBase4 = new THREE.Mesh(bedBase4_geometry, grigioMetallico);
      bedBase4.position.y = 0.5 + 4.7;
      letto.add( bedBase4 );

      var cuscino = creaCuscino();
      cuscino.position.y = 1 + 4 +8;
      cuscino.position.x = 11.5; 
      letto.add( cuscino);

      var bedWall_geometry = new THREE.BoxGeometry( 0.5 ,8, 14.5 );
      var bedWall_geometry1 = new THREE.BoxGeometry( 0.5,2, 15 );
      var bedHeadWall_geometry = new THREE.BoxGeometry( 0.5,2, 7 );
      var bedWall_material= new THREE.MeshLambertMaterial({ color : 0x000000});
      var bedWallForward = new THREE.Mesh(bedWall_geometry, grigio);
      var bedWallBackward = new THREE.Mesh(bedWall_geometry, grigio);
      bedWallBackward.position.x = -15.5;
      bedWallBackward.position.y = 8+ 7/2;
      bedWallForward.position.x = 15.5;
      bedWallForward.position.y = 8 + 7/2;
     
      letto.add( bedWallForward );
      letto.add( bedWallBackward );

      var o5 = new THREE.Object3D();

      letto.add( o5 );
      o5.position.y = 8;
  
      var SG = new THREE.SphereGeometry( 0.3 , Math.round(32*detail) ,Math.round(32*detail) );
      var baseG = new THREE.CylinderGeometry( 0.7 , 0.7  , 1.6 , Math.round(32*detail) );
      var pioloG = new THREE.CylinderGeometry( 0.1 , 0.1 , 2 , Math.round(32*detail) );
      var bedWallTube_geometry = new THREE.CylinderGeometry( 0.3 , 0.3 , 7 , Math.round(32*detail) );
      var bedWallTube1 = new THREE.Mesh( bedWallTube_geometry, grigioMetallico);
      var bedWallTube2 = new THREE.Mesh( bedWallTube_geometry, grigioMetallico);
      var bedWallTube3 = new THREE.Mesh( bedWallTube_geometry, grigioMetallico);
      var bedWallTube4 = new THREE.Mesh( bedWallTube_geometry, grigioMetallico);
      var sfera1 = new THREE.Mesh( SG, grigioMetallico);
      var sfera2 = new THREE.Mesh( SG, grigioMetallico);
      var piolo1 = new THREE.Mesh( pioloG, grigio);
      var piolo2 = new THREE.Mesh( pioloG, grigio);
      var piolo3 = new THREE.Mesh( pioloG, grigio);
      var piolo4 = new THREE.Mesh( pioloG, grigio);
      var base1 = new THREE.Mesh(baseG, grigio);
      var base2 = new THREE.Mesh(baseG, grigio);
      var base3 = new THREE.Mesh(baseG, grigio);
      var base4 = new THREE.Mesh(baseG, grigio);

      bedWallTube1.position.set( 15.5 , 4 , 7.5 );
      piolo1.position.set(15.5, 4+3.5, 7.5);
      base1.position.set(15.5, -0.5, 7.5)

      bedWallTube2.position.set( 15.5 , 4 , -7.5 );
      piolo2.position.set(15.5, 4+3.5, -7.5);
      base2.position.set(15.5, -0.5, -7.5)

      bedWallTube3.position.set( -15.5 , 4 , 7.5 );
      piolo3.position.set(-15.5, 4+3.5, 7.5);
      base3.position.set(-15.5, -0.5, 7.5)
      sfera1.position.set(-14, -0.5, 7.5);

      bedWallTube4.position.set( -15.5 , 4 , -7.5 );
      piolo4.position.set(-15.5, 4+3.5, -7.5);
      base4.position.set(-15.5, -0.5, -7.5)
      sfera2.position.set(-14, -0.5, -7.5);

      o5.add(bedWallTube1);
      o5.add(bedWallTube2);
      o5.add(bedWallTube3);
      o5.add(bedWallTube4);
      o5.add(piolo1);
      o5.add(piolo2);
      o5.add(piolo3);
      o5.add(piolo4);
      o5.add(base1);
      o5.add(base2);
      o5.add(base3);
      o5.add(base4);

      var bedWallUpperTube_geometry = new THREE.CylinderGeometry( 0.3 , 0.3 , 15 , Math.round(32*detail) );
      var bedWallUpperTube1 = new THREE.Mesh( bedWallUpperTube_geometry , grigioMetallico);
      var bedWallUpperTube2 = new THREE.Mesh( bedWallUpperTube_geometry , grigioMetallico);

      bedWallUpperTube1.rotation.x = Math.PI/2;
      bedWallUpperTube1.position.y = 8.5;
      bedWallUpperTube1.position.x = 15.5;

      bedWallUpperTube2.rotation.x = Math.PI/2;
      bedWallUpperTube2.position.y = 8.5;
      bedWallUpperTube2.position.x = -15.5;

      var bedWallUpperSphere1_geometry = new THREE.SphereGeometry( 0.3 , Math.round(32*detail) ,Math.round(32*detail) );
      var bedWallUpperSphere1 = new THREE.Mesh(bedWallUpperSphere1_geometry , bedWall_material);
      var bedWallUpperSphere2 = new THREE.Mesh(bedWallUpperSphere1_geometry , bedWall_material);
      var bedWallUpperSphere3 = new THREE.Mesh(bedWallUpperSphere1_geometry , bedWall_material);
      var bedWallUpperSphere4 = new THREE.Mesh(bedWallUpperSphere1_geometry , bedWall_material);
      bedWallUpperSphere1.position.set( 15.5 , 8.5 , 7.5)
      bedWallUpperSphere2.position.set( 15.5 , 8.5 , -7.5)
      bedWallUpperSphere3.position.set( -15.5 , 8.5 , 7.5)
      bedWallUpperSphere4.position.set( -15.5 , 8.5 , -7.5)

      o5.add(bedWallUpperSphere1);
      o5.add(bedWallUpperSphere2);
      o5.add(bedWallUpperSphere3);
      o5.add(bedWallUpperSphere4);

      o5.add( bedWallUpperTube1);
      o5.add( bedWallUpperTube2);


// Manici laterali

    var manicoAD = creaManico();
    letto.add(manicoAD);

    var manicoAS = creaManico();
    manicoAS.position.z = -16;
    letto.add(manicoAS);

    var manicoBD = creaManico();
    manicoBD.position.x = -16;
    letto.add(manicoBD);

    var manicoBS = creaManico();
    manicoBS.position.x = -16;
    manicoBS.position.z = -16;
    letto.add(manicoBS);

function creaManico(){

    var manico = new THREE.Object3D( );

    var maniciPG = new THREE.CylinderGeometry( 0.2 , 0.2 , 3 , Math.round(32*detail) );
    var sferaM = new THREE.SphereGeometry( 0.2 , Math.round(32*detail) , Math.round(32*detail) );
    var maniciPGO = new THREE.CylinderGeometry( 0.2 , 0.2 , 8 , Math.round(32*detail) );
    var maniciPd1 = new THREE.Mesh( maniciPG , grigioMetallico);
    var maniciPd2 = new THREE.Mesh( maniciPG , grigioMetallico);
    var maniciPsO = new THREE.Mesh( maniciPGO , grigioMetallico);
    var sferaAS = new THREE.Mesh( sferaM , grigio);
    var sferaAD = new THREE.Mesh( sferaM , grigio);


    maniciPd1.rotation.y = Math.PI/2;
    maniciPd1.position.y = 8.5 + 1.5;
    maniciPd1.position.x = 12;
    maniciPd1.position.z = 8;

    maniciPd2.rotation.y = Math.PI/2;
    maniciPd2.position.y = 8.5 + 1.5;
    maniciPd2.position.x = 4;
    maniciPd2.position.z = 8;

    maniciPsO.rotation.z = Math.PI/2;
    maniciPsO.position.y = 8.5 + 1.5 + 1.5 ;
    maniciPsO.position.z = 8;
    maniciPsO.position.x = 8;


    sferaAS.position.y = 8.5 + 1.5 + 1.5 ;
    sferaAS.position.z = 8;
    sferaAS.position.x = 4;

    sferaAD.position.y = 8.5 + 1.5 + 1.5 ;
    sferaAD.position.z = 8;
    sferaAD.position.x = 12;

    manico.add(maniciPd1);
    manico.add(maniciPd2);
    manico.add(maniciPsO);
    manico.add(sferaAS);
    manico.add(sferaAD);

    return manico;
  }

// Ruota 1

      var o1 = new THREE.Object3D();
      o1.position.x = 12.5;
      o1.position.y = 2.5;
      letto.add(o1);

      var wheel_geometry = new THREE.TorusGeometry( 1, 0.5, Math.round(32*detail), Math.round(64*detail) );
      var wheel_material = new THREE.MeshBasicMaterial( { color: 0x00000 , antialias : true } );
      var wheel1 = new THREE.Mesh( wheel_geometry, wheel_material );

      var wheelCenter_geometry = new THREE.CylinderGeometry( 1.2 , 0.4 , 2 , Math.round(32*detail));
      var wheelCenter1 = new THREE.Mesh( wheelCenter_geometry , grigioMetallico );
      wheelCenter1.rotation.x = Math.PI /2;
      wheelCenter1.position.z = -0.5;
      wheel1.add(wheelCenter1);

      var wheelJoint_geometry = new THREE.SphereGeometry( 0.48 , Math.round(32*detail) , Math.round(32*detail) );
      var wheelJoint1 = new THREE.Mesh(wheelJoint_geometry , grigioMetallico );

      var wheelBedConnector_geometry = new THREE.CylinderGeometry( 0.4 , 0.4 , 2 , Math.round(32*detail));
      var wheelBedConnector = new THREE.Mesh( wheelBedConnector_geometry , grigioMetallico );
      wheelBedConnector.position.y = 1;
      wheelBedConnector.position.z = -1.6;
      wheel1.add(wheelBedConnector);
   
      wheel1.position.z = 6.7;
      wheel1.position.y = 0.4;    
      
      o1.add( wheel1 );

//Ruota 2

      var o2 = new THREE.Object3D();
      var wheel2 = new THREE.Mesh( wheel_geometry, wheel_material );
      var wheelCenter2 = new THREE.Mesh( wheelCenter_geometry , grigioMetallico );
      //var wheelJoint2 = new THREE.Mesh(wheelJoint_geometry , grigioMetallico );
      var wheelBedConnector2 = new THREE.Mesh( wheelBedConnector_geometry , grigioMetallico);
      var wheelBedConnector1 = new THREE.Mesh( wheelBedConnector_geometry , grigioMetallico);
     
      wheelBedConnector1.position.y = 1;
      wheelBedConnector1.position.z = -12.3;

      o2.rotation.y = Math.PI;
      wheelBedConnector2.position.y = 1;
      wheelBedConnector2.position.z = -1.14;
      wheel2.add(wheelBedConnector2);
      wheel2.add(wheelBedConnector1);

     // wheelJoint2.position.z = -1.5;
      wheelCenter2.rotation.x = Math.PI /2;
      wheelCenter2.position.z = -0.5;
      wheel2.position.z = 6.7;
      wheel2.position.y = 0.4;
      o2.add( wheel2 );
      wheel2.add(wheelCenter2);
     // wheel2.add(wheelJoint2);
      o1.add(o2);

//Ruota 3

      var o3 = new THREE.Object3D();
      var wheel3 = new THREE.Mesh( wheel_geometry, wheel_material );
      var wheelCenter3 = new THREE.Mesh( wheelCenter_geometry , grigioMetallico );
      var wheelJoint3 = new THREE.Mesh(wheelJoint_geometry ,grigioMetallico );
      var wheelBedConnector3 = new THREE.Mesh( wheelBedConnector_geometry , grigioMetallico);

      o3.rotation.y = Math.PI;
      o3.position.x = -12.5;
      o3.position.y = 2.5;
      letto.add(o3);


      wheelBedConnector3.position.y = 1;
      wheelBedConnector3.position.z = -1.6;
      wheel3.add(wheelBedConnector);
      wheelJoint3.position.z = -1.5;
      wheelCenter3.rotation.x = Math.PI /2;
      wheelCenter3.position.z = -0.5;
      wheel3.position.z = 6.7;
      wheel3.position.y = 0.4;
      o3.add( wheel3 );
      wheel3.add(wheelCenter3);
      wheel3.add(wheelJoint3);


      var o4 = new THREE.Object3D();
      var wheel4 = new THREE.Mesh( wheel_geometry, wheel_material );
      var wheelCenter4 = new THREE.Mesh( wheelCenter_geometry , grigioMetallico );
      var wheelJoint4 = new THREE.Mesh(wheelJoint_geometry , grigioMetallico );
      var wheelBedConnector4 = new THREE.Mesh( wheelBedConnector_geometry ,grigioMetallico);

      o4.rotation.y = Math.PI;
      wheelBedConnector4.position.y = 1;
      wheelBedConnector4.position.z = -1.6;
      wheel4.add(wheelBedConnector4);
      wheelJoint4.position.z = -1.5;
      wheelCenter4.rotation.x = Math.PI /2;
      wheelCenter4.position.z = -0.5;
      wheel4.position.z = 6.7;
      wheel4.position.y = 0.4;
      o4.add( wheel4 );
      wheel4.add(wheelCenter4);
      wheel4.add(wheelJoint4);
      o3.add(o4);

      function creaCuscino(){
      var cuscino = new THREE.Object3D();
      var geometriaBordoCorto = new THREE.CylinderGeometry( 1 , 1 , 4 , Math.round(32*detail) );
      var geometriaBordoLungo = new THREE.CylinderGeometry( 1 , 1 , 12 , Math.round(32*detail) );
      var geometriaAngolo = new THREE.SphereGeometry( 1 , Math.round(32*detail) , Math.round(32*detail) );
      var pillow_geometry = new THREE.BoxGeometry( 4 , 2  , 12 );
      var pillow_material = new THREE.MeshLambertMaterial({color: 0xFFFFFF});
      var pillow = new THREE.Mesh(pillow_geometry,pillow_material);
      var bordoCorto1 = new THREE.Mesh(geometriaBordoCorto, pillow_material);
      var bordoCorto2 = new THREE.Mesh(geometriaBordoCorto, pillow_material);
      var bordoLungo1 = new THREE.Mesh(geometriaBordoLungo, pillow_material);
      var bordoLungo2 = new THREE.Mesh(geometriaBordoLungo, pillow_material);
      var angolo1 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo2 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo3 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo4 = new THREE.Mesh(geometriaAngolo, pillow_material);
      bordoLungo1.rotation.x = Math.PI/2;
      bordoLungo1.position.x = 2;
      bordoLungo2.rotation.x = Math.PI/2;
      bordoLungo2.position.x =-2;
      bordoCorto1.rotation.z = Math.PI/2;
      bordoCorto1.position.z = 6;
      bordoCorto2.rotation.z = Math.PI/2;
      bordoCorto2.position.z =-6;
      angolo1.position.y = 6;
      angolo3.position.y = 6;
      angolo2.position.y =-6;
      angolo4.position.y =-6;
      bordoLungo1.add(angolo1);
      bordoLungo1.add(angolo2);
      bordoLungo2.add(angolo3);
      bordoLungo2.add(angolo4);
      pillow.add(bordoLungo1);
      pillow.add(bordoLungo2);
      pillow.add(bordoCorto2);
      pillow.add(bordoCorto1);
      cuscino.add(pillow)
      return cuscino;
    };

    function  creaMaterasso(){
      var bed_geometry = new THREE.BoxGeometry( 30 , 4  , 15 );
      var materasso = new THREE.Object3D();
      var geometriaBordoCorto = new THREE.CylinderGeometry( 2 , 2 , 12 , Math.round(32*detail) );
      var geometriaBordoLungo = new THREE.CylinderGeometry( 2 , 2 , 27 , Math.round(32*detail) );
      var geometriaAngolo = new THREE.SphereGeometry( 2 , Math.round(32*detail) , Math.round(32*detail) );
      var pillow_geometry = new THREE.BoxGeometry( 12 , 4  , 27 );
      var pillow_material = new THREE.MeshLambertMaterial({color: 0xFFFFFF});
      var pillow = new THREE.Mesh(pillow_geometry,pillow_material);
      var bordoCorto1 = new THREE.Mesh(geometriaBordoCorto, pillow_material);
      var bordoCorto2 = new THREE.Mesh(geometriaBordoCorto, pillow_material);
      var bordoLungo1 = new THREE.Mesh(geometriaBordoLungo, pillow_material);
      var bordoLungo2 = new THREE.Mesh(geometriaBordoLungo, pillow_material);
      var angolo1 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo2 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo3 = new THREE.Mesh(geometriaAngolo, pillow_material);
      var angolo4 = new THREE.Mesh(geometriaAngolo, pillow_material);
      bordoLungo1.rotation.x = Math.PI/2;
      bordoLungo1.position.x = 6;
      bordoLungo2.rotation.x = Math.PI/2;
      bordoLungo2.position.x =-6;
      bordoCorto1.rotation.z = Math.PI/2;
      bordoCorto1.position.z = 13.5;
      bordoCorto2.rotation.z = Math.PI/2;
      bordoCorto2.position.z =-13.5;
      angolo1.position.y = 13.5;
      angolo3.position.y = 13.5;
      angolo2.position.y =-13.5;
      angolo4.position.y =-13.5;
      bordoLungo1.add(angolo1);
      bordoLungo1.add(angolo2);
      bordoLungo2.add(angolo3);
      bordoLungo2.add(angolo4);
      pillow.add(bordoLungo1);
      pillow.add(bordoLungo2);
      pillow.add(bordoCorto2);
      pillow.add(bordoCorto1);
      materasso.add(pillow);
      materasso.rotation.y = Math.PI/2;
      return materasso;
    };
      var tex = new THREE.MeshPhongMaterial( {color: 0xF0DC82});
      var texture = THREE.ImageUtils.loadTexture("/assets/textures/com.jpg");
      tex.map = texture;
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );

      var tex2 = new THREE.MeshPhongMaterial( {color: 0xF0DC82});
      var texture2 = THREE.ImageUtils.loadTexture("/assets/textures/pulse.png");
      tex2.map = texture2;
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );


      var controlli = new THREE.Object3D();
      var geometria = new THREE.BoxGeometry(3.5, 0.3, 0.02);
      var geometria2 = new THREE.BoxGeometry(0.5, 0.1, 0.03);
      var geometria3 = new THREE.BoxGeometry(0.5, 0.2, 0.03);
      var geometria4 = new THREE.BoxGeometry(1, 0.2, 0.03);

      var base = new THREE.Mesh(geometria, grigioMetallico);
      var pri = new THREE.Mesh(geometria2, tex);
      pri.position.set(1.45, -0.05, 0);
      var pri2 = new THREE.Mesh(geometria3, tex2);
      
      var pri3 = new THREE.Mesh(geometria4, tex);
      pri3.position.set(-1.2, 0, 0);

      base.add(pri);
      base.add(pri2);
      base.add(pri3);
      base.rotation.y += Math.PI/2;
      base.scale.set(10, 10, 10);

      letto.add(base);
      base.position.set(17, 25, 0);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.03,0.03,0.1,80);
      var comando2 = new THREE.Mesh(cylinderGeometry1, grigio);
      comando2.position.set(-0.14,1,0.20);
      base.add(comando2);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.01,0.01,0.04,80);
      var comando2e = new THREE.Mesh(cylinderGeometry1, metal);
      comando2e.position.y -= 0.035;
      
      comando2.add(comando2e);

      comando2.rotation.x += Math.PI/2;
      comando2.position.y -= 1;
      comando2.position.z -= 0.2;
      comando2.position.x += 1;

       var cylinderGeometry1 = new THREE.CylinderGeometry(0.03,0.03,0.1,80);
      var comando1 = new THREE.Mesh(cylinderGeometry1, grigio);
      comando1.position.set(-0.14,1,0.20);
      base.add(comando1);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.01,0.01,0.04,80);
      var comando1e = new THREE.Mesh(cylinderGeometry1, c );
      comando1e.position.y -= 0.035;
      
      comando1.add(comando1e);

      comando1.rotation.x += Math.PI/2;
      comando1.position.y -= 1;
      comando1.position.z -= 0.2;
      comando1.position.x += 1.2;

       var cylinderGeometry1 = new THREE.CylinderGeometry(0.03,0.03,0.1,80);
      var comando3 = new THREE.Mesh(cylinderGeometry1, grigio);
      comando3.position.set(-0.14,1,0.20);
      base.add(comando3);

      var cylinderGeometry1 = new THREE.CylinderGeometry(0.01,0.01,0.04,80);
      var comando3e = new THREE.Mesh(cylinderGeometry1, c1 );
      comando3e.position.y -= 0.035;
      
      comando3.add(comando3e);

      comando3.rotation.x += Math.PI/2;
      comando3.position.y -= 1;
      comando3.position.z -= 0.2;
      comando3.position.x += 0.8;


    letto.scale.set(0.06, 0.06, 0.06);
	return letto;
};

Letto.prototype.in_graph = true;
Letto.prototype.in_2D_map = false;

module.exports = Letto;