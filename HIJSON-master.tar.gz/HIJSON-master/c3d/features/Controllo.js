var Feature = require('./Feature.js');

Feature.inherits(Controllo, Feature);

function Controllo(feature) {
	Feature.call(this, feature);
}
Controllo.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Controllo.prototype.in_graph = true;
Controllo.prototype.in_2D_map = false;

Controllo.prototype.get3DModel = function() {

	  var colore = new THREE.MeshLambertMaterial({color : 0xffffff});
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} )
      var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
      var ka = 0.4;
      grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );


      var bianco = new THREE.MeshLambertMaterial({color : 0xFFFFFF});
      //var nero = new THREE.MeshLambertMaterial({color : 0x000000});

      var nero = new THREE.MeshLambertMaterial( { color: 0x000000, shading: THREE.FlatShading } );
      var ka = 0.4;
      nero.ambient.setRGB( nero.color.r * ka, nero.color.g * ka, nero.color.b * ka );

      var grigioChiaro = new THREE.MeshLambertMaterial({color : 0xD3D3D3});
      var grigioMetallico = new THREE.MeshLambertMaterial({color : 0x98AFC7});
      var celesteMetallo = new THREE.MeshLambertMaterial({color : 0xB0C4DE});
      
      var tex = new THREE.MeshPhongMaterial( {color: 0xF0DC82});
      var texture = THREE.ImageUtils.loadTexture("assets/textures/com.jpg");
      tex.map = texture;

      var controlli = new THREE.Object3D();
      var geometria = new THREE.BoxGeometry(2, 0.3, 0.02);
      var geometria2 = new THREE.BoxGeometry(0.5, 0.1, 0.03);


      var base = new THREE.Mesh(geometria, colore);
      var pri = new THREE.Mesh(geometria2, tex);
      controlli.add(base);
      base.add(pri);
      pri.position.set(0.5, -0.05, 0);


      return controlli;
}


module.exports = Controllo;