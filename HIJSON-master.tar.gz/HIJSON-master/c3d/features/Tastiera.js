var Feature = require('./Feature.js');

Feature.inherits(Tastiera, Feature);

function Tastiera(feature) {
  Feature.call(this, feature);
}

Tastiera.prototype.style = {
  prefix: "fa",
  icon: "minus",
  zIndex: 3
};

Tastiera.prototype.in_graph = true;
Tastiera.prototype.in_2D_map = false;

Tastiera.prototype.get3DModel = function() {

      var tastiera = new THREE.Object3D();

      var mat_nero = new THREE.MeshPhongMaterial( {color: 0xffffff});
      
      var texture = THREE.ImageUtils.loadTexture("assets/textures/tastiera.jpg");
        mat_nero.map = texture;
      var texture2 = THREE.ImageUtils.loadTexture("assets/textures/tastiera.jpg");
        var mat = new THREE.MeshPhongMaterial( {color: 0x000000});
        mat.map = texture2;

        var texture3 = THREE.ImageUtils.loadTexture("assets/textures/mouse.png");
        var mat2 = new THREE.MeshPhongMaterial( {color: 0x000000});
        mat2.map = texture3;

      var spessore = new THREE.Mesh(new THREE.BoxGeometry(0.4,0.2,0.01), mat_nero);
      var superficie = new THREE.Mesh(new THREE.PlaneGeometry(0.4,0.2), mat);
      superficie.position.z -= 0.01;

      tastiera.add(superficie);
      tastiera.add(spessore);
      tastiera.rotation.x+=Math.PI/2;

      var spessore2 = new THREE.Mesh(new THREE.BoxGeometry(0.05,0.08,0.01), mat2);
      var superficie2 = new THREE.Mesh(new THREE.PlaneGeometry(0.05,0.08), mat2);
      superficie2.position.z -= 0.01;
      spessore2.add(superficie2);
      spessore2.position.x -= 0.35;
      tastiera.add(superficie2);
      tastiera.add(spessore2);



return tastiera;


}
module.exports = Tastiera;