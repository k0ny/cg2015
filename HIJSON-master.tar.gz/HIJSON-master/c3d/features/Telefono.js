var Feature = require('./Feature.js');

Feature.inherits(Telefono, Feature);

function Telefono(feature) {
	Feature.call(this, feature);
}

Telefono.prototype.style = {
			    			prefix: "fa",
			    			markerColor: "green",
	    					icon: "phone",
	    					zIndex: 3
						};

Telefono.prototype.in_graph = true;

Telefono.prototype.in_2D_map = true;

Telefono.prototype.get3DModel = function() {
	var telefono = new THREE.Object3D();

var grigio = new THREE.MeshLambertMaterial( { color: 0x8F8F8F, shading: THREE.FlatShading } );
      var ka = 0.4;
      grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );

	var mat_nero = new THREE.MeshPhongMaterial( {color: 0xffffff});
	var texture2 = THREE.ImageUtils.loadTexture("assets/textures/telefono.jpg");
    var mat = new THREE.MeshPhongMaterial( {color: 0xffffff});
    mat.map = texture2;

	var spessore = new THREE.Mesh(new THREE.BoxGeometry(0.2,0.2,0.05), mat_nero);
	var superficie = new THREE.Mesh(new THREE.PlaneGeometry(0.2,0.2), mat);
	superficie.position.z+=0.03;

	telefono.add(superficie);
	telefono.add(spessore);
	telefono.rotation.x+=Math.PI/2;
	return telefono;
};

module.exports = Telefono;