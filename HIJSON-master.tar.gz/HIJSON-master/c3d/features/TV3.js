var Feature = require('./Feature.js');

Feature.inherits(TV3, Feature);

function TV3(feature) {
  Feature.call(this, feature);
}

TV3.prototype.style = {
                prefix: "fa",
                icon: "medkit",
                zIndex: 3
            };

TV3.prototype.in_graph = true;

TV3.prototype.in_2D_map = false;

TV3.prototype.get3DModel = function() {


     var gray_material = new THREE.MeshLambertMaterial({color : 0xa9a9a9});
     var black_material = new THREE.MeshLambertMaterial({color : 0x000000});

     var screen = new THREE.Object3D( );

             var black = new THREE.MeshLambertMaterial( { color: 0x000000, shading: THREE.FlatShading } );
              var ka = 0.4;
              black.ambient.setRGB( black.color.r * ka, black.color.g * ka, black.color.b * ka );

            var tex = new THREE.MeshPhongMaterial( {color: 0xffffff});
            var texture = THREE.ImageUtils.loadTexture("assets/textures/desktop.jpg");
            tex.map = texture;

            var screen_geometry = new THREE.BoxGeometry( 0.8 , 0.01 , 0.4);
            var screen = new THREE.Mesh(screen_geometry, tex);
            screen.position.y = 0.01/2;

            var screenRam1_geometry = new THREE.BoxGeometry( 0.9 , 0.02 , 0.03 );
            var screenRam1 = new THREE.Mesh(screenRam1_geometry,black);
            screenRam1.position.z = -0.2-0.03/2;
            screen.add(screenRam1);

            var screenRam2_geometry = new THREE.BoxGeometry( 0.9 , 0.02 , 0.04 );
            var screenRam2 = new THREE.Mesh(screenRam2_geometry,black);
            screenRam2.position.z = 0.2+0.02;
            screen.add(screenRam2);

            var screenRam3_geometry = new THREE.BoxGeometry( 0.1/2 , 0.02 , 0.4 );
            var screenRam3a = new THREE.Mesh(screenRam3_geometry,black);
            var screenRam3b = new THREE.Mesh(screenRam3_geometry,black);
            screenRam3a.position.x = 0.4 + 0.1/4;
            screenRam3b.position.x = -0.4 - 0.1/4;

            screen.add(screenRam3a);
            screen.add(screenRam3b);

            var screenRam4_geometry = new THREE.BoxGeometry( 0.9 , 0.001 , 0.4 );
            var screenRam4 =new THREE.Mesh(screenRam4_geometry, black);
            screenRam4.position.y = -0.01/2;
            screen.add(screenRam4);

            var cil = new THREE.CylinderGeometry(0.01, 0.01, 0.25, 32);
            var cilindro = new THREE.Mesh(cil, black);
            cilindro.rotation.x -= Math.PI/2;
            cilindro.position.set(0, -0.025, 0.2)
            var qua = new THREE.BoxGeometry(0.1, 0.05, 0.05);
            var box = new THREE.Mesh(qua, black);
            //box.rotation.x -= Math.PI/2;
            box.position.set(0, 0.1, 0);
            var cil2 = new THREE.CylinderGeometry(0.02, 0.2, 0.025, 32);
            var cilindro2 = new THREE.Mesh(cil2, black);
           // cilindro2.rotation.x -= Math.PI/2;
            cilindro2.position.set(0, -0.13, 0);

            cilindro.add(cilindro2);
            cilindro.add(box);

            screen.add(cilindro);   
 
      screen.rotation.x = Math.PI/2;
      screen.rotation.z = Math.PI;
      screen.scale.set(0.6, 0.6, 0.6);
      

      return screen;
};

module.exports = TV3;