var Feature = require('./Feature.js');

Feature.inherits(Comodino, Feature);

function Comodino(feature) {
	Feature.call(this, feature);
}
Comodino.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Comodino.prototype.in_graph = true;
Comodino.prototype.in_2D_map = false;

Comodino.prototype.get3DModel = function() {

      var armadio = new THREE.Object3D();


        var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
      var legno = new THREE.MeshPhongMaterial( {color: 0x000000});
	    var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
      legno.map = texture;

      var bisturi = new THREE.MeshPhongMaterial( {color: 0x000000});
      var texture = THREE.ImageUtils.loadTexture("assets/textures/bisturi.jpg");
      bisturi.map = texture;



      var comodino = new THREE.Object3D();

      var geometria = new THREE.BoxGeometry(0.7, 0.2, 0.7);

      var cassetto1 = new THREE.Mesh( geometria, metal ) ;
      var maniglia1 = new Maniglia();
      comodino.add(cassetto1);
      cassetto1.position.y += 0.1;
      cassetto1.add(maniglia1);
      maniglia1.position.x -= 0.5;
      maniglia1.rotation.x += Math.PI/2;
      maniglia1.rotation.y += Math.PI/2;
      maniglia1.rotation.z += Math.PI/2;

      var cassetto2 = new THREE.Mesh( geometria, metal ) ;
      var maniglia2 = new Maniglia();
      comodino.add(cassetto2);
      cassetto2.position.y += 0.3005;
      cassetto2.add(maniglia2);
      maniglia2.position.x -= 0.5;
      maniglia2.rotation.x += Math.PI/2;
      maniglia2.rotation.y += Math.PI/2;
      maniglia2.rotation.z += Math.PI/2;

      var cassetto3 = new THREE.Mesh( geometria, metal ) ;
      var maniglia3 = new Maniglia();
      comodino.add(cassetto3);
      cassetto3.position.y += 0.501;
      cassetto3.add(maniglia3);
      maniglia3.position.x -= 0.5;
      maniglia3.rotation.x += Math.PI/2;
      maniglia3.rotation.y += Math.PI/2;
      maniglia3.rotation.z += Math.PI/2;

      geometriaB = new THREE.BoxGeometry(0.7, 0.01, 0.7);
      var bi = new THREE.Mesh( geometriaB, bisturi ) ;
      comodino.add(bi);
      bi.position.y += 0.501  + 0.1;


        function Maniglia() {

        var maniglia = new THREE.Object3D();
        
        var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02,0.7 ,32);
        var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);

        var appendino = new THREE.Mesh( appendino_geo, metal ) ;
        var braccio1 = new THREE.Mesh( braccio_geo, metal ) ;
        var braccio2 = new THREE.Mesh( braccio_geo, metal ) ;

        appendino.rotation.z-=Math.PI/2;
        appendino.position.y-=0.2;
        appendino.position.z+=0.45;


        braccio1.position.z+=0.45;
        braccio1.position.x+=0.25;
        braccio1.position.y-=0.1;
        braccio2.position.z+=0.45;
        braccio2.position.x-=0.25;
        braccio2.position.y-=0.1;
        maniglia.add(braccio1);
        maniglia.add(braccio2);
        maniglia.add(appendino);
        maniglia.rotation.z+=Math.PI/2;
        maniglia.rotation.y+=Math.PI/2;
        maniglia.position.x -= 0.18;
        maniglia.position.z -= 0.15;
        maniglia.position.y += 0.18;
        maniglia.scale.set(0.4,0.4,0.4);
        maniglia.rotation.y += Math.PI;
        maniglia.position.z += 0.48;
        maniglia.position.x += 0.7;
        return maniglia;
      }
       var lampada = new THREE.Object3D();

      var stoffa = new THREE.MeshPhongMaterial( {color: 0xffffff});
      stoffa.map = texture;
      stoffa.side = THREE.DoubleSide;

      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
        
      var base_geo = new THREE.CylinderGeometry( 0.3, 0.3, 0.1 ,32);
      var piano = new THREE.Mesh( base_geo, metal ) ;
      
      var zampa_geo = new THREE.CylinderGeometry( 0.01, 0.02, 1,4);
      var zampa = new THREE.Mesh( zampa_geo, metal ) ;
      zampa.position.y+=0.5;

      var semisfera = new THREE.SphereGeometry(0.3, 8, 6, 0, Math.PI, 0, Math.PI);
      var copriluce = new THREE.Mesh( semisfera, metal ) ;
      copriluce.rotation.x-=Math.PI/2;
      copriluce.position.y+=1;
      
      lampada.add(zampa);
      lampada.add(piano);
      copriluce.position.z += 0.2;
      lampada.add(copriluce);
      //lampada.rotation.x+=Math.PI/2;
      lampada.position.y += 0.2*3 ;
      lampada.position.z -= 0.1;
      lampada.position.x += 0.1;
      lampada.scale.set(0.3,0.3,0.3);


      //comodino.add(lampada);

      var g2 = new THREE.BoxGeometry(0.6, 0.1, 0.6);
      var sottocassetto = new THREE.Mesh(g2, metal);
      sottocassetto.position.z -= 0.01;
      comodino.add(sottocassetto);

      return comodino;
  }
  module.exports = Comodino;