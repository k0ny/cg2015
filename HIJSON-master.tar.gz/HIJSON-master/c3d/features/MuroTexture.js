var Feature = require('./Feature.js');

Feature.inherits(MuroTexture, Feature);

function MuroTexture(feature) {
	Feature.call(this, feature);
};

MuroTexture.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
};

MuroTexture.prototype.in_graph = true;

MuroTexture.prototype.in_2D_map = false;

MuroTexture.prototype.get3DModel = function() {
	var pavimento = new THREE.Object3D();

	var lato1 = 7.5;
	var lato2 = 3.5;
	
	var texture1 = THREE.ImageUtils.loadTexture("assets/textures/pvc3.jpg");
   
    texture1.wrapS = THREE.RepeatWrapping;
    texture1.wrapT = THREE.RepeatWrapping;
    var marmo = new THREE.MeshPhongMaterial();
    marmo.map = texture1;
	marmo.map.repeat.set(lato1, lato2);
    var piastrelle = new THREE.Mesh(new THREE.BoxGeometry(lato1, 0.05, lato2), marmo);
    piastrelle.rotation.x+=Math.PI/2;
    pavimento.add(piastrelle);

    pavimento.rotation.x += Math.PI / 2;
    pavimento.position.x += lato1 / 2;
    pavimento.position.z += lato2 / 2 ;
    pavimento.position.y -= 0.05;
    
	return pavimento;

};

module.exports = MuroTexture;