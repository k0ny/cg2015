var Feature = require('./Feature.js');

Feature.inherits(PavimentoStanze, Feature);

function PavimentoStanze(feature) {
	Feature.call(this, feature);
};

PavimentoStanze.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
};

PavimentoStanze.prototype.in_graph = true;

PavimentoStanze.prototype.in_2D_map = false;

PavimentoStanze.prototype.get3DModel = function() {
	var pavimento = new THREE.Object3D();

	var lato1 = 7.5;
	var lato2 = 30;
	 
	//var texture1 = THREE.ImageUtils.loadTexture("assets/textures/marmo2.jpg");

	var texture1 = THREE.ImageUtils.loadTexture("assets/textures/parquet2.jpg");

    texture1.wrapS = THREE.RepeatWrapping;
    texture1.wrapT = THREE.RepeatWrapping;

    var marmo = new THREE.MeshPhongMaterial();
    marmo.map = texture1;
	marmo.map.repeat.set(lato1, lato2);
    var piastrelle = new THREE.Mesh(new THREE.BoxGeometry(lato1, 0.05, lato2), marmo);
    piastrelle.rotation.x+=Math.PI/2;
    pavimento.add(piastrelle);
	return pavimento;
};

module.exports = PavimentoStanze;