var Feature = require('./Feature.js');

Feature.inherits(Tavolino, Feature);Tavolino

function Tavolino(feature) {
	Feature.call(this, feature);
}

Tavolino.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
						};

Tavolino.prototype.in_graph = true;
Tavolino.prototype.in_2D_map = false;

Tavolino.prototype.get3DModel = function() {
	var chair = new THREE.Object3D();

	var geometry = new THREE.CylinderGeometry( 0.015, 0.015, 0.5, 32 );
	var material = new THREE.MeshLambertMaterial( {color: 0xd9d7d7} );
	var legno = new THREE.MeshPhongMaterial( {color: 0xF0DC82});
    var texture = THREE.ImageUtils.loadTexture("assets/textures/legno-porta.jpg");
    legno.map = texture;

	var p1 = new THREE.Mesh( geometry, legno );
	p1.name = "p1_" + this.id;
	p1.rotation.x += Math.PI/2;
	p1.position.z += 0.5/2;

	var p2 = new THREE.Mesh( geometry, legno );
	p2.name = "p2_" + this.id;
	p2.rotation.x += Math.PI/2;
	p2.position.z += 0.5/2;
	p2.position.y += 0.4;

	var p3 = new THREE.Mesh( geometry, legno );
	p3.name = "p3_" + this.id;
	p3.rotation.x += Math.PI/2;
	p3.position.z += 0.5/2;
	p3.position.x += 0.4;

	var p4 = new THREE.Mesh( geometry, legno );
	p4.name = "p4_" + this.id;
	p4.rotation.x += Math.PI/2;
	p4.position.z += 0.5/2;
	p4.position.y += 0.4;
	p4.position.x += 0.4;

	var p5 = new THREE.Mesh( geometry, legno );
	p5.name = "p5_" + this.id;
	p5.rotation.x += Math.PI/2;
	p5.position.z += 0.5*3/2;

	var p6 = new THREE.Mesh( geometry, legno );
	p6.name = "p6_" + this.id;
	p6.rotation.x += Math.PI/2;
	p6.position.z += 0.5*3/2;
	p6.position.x += 0.4;

	geometry = new THREE.BoxGeometry( 0.45, 0.45, 0.02 );
	material = new THREE.MeshLambertMaterial( {color: 0x9b8c75} );
	var plane = new THREE.Mesh( geometry, legno );
	plane.name = "plane_" + this.id;
	plane.position.x += 0.4/2;
	plane.position.y += 0.4/2;
	plane.position.z += 0.5;

	
	chair.add(plane);
	chair.add(p1);
	chair.add(p2);
	chair.add(p3);
	chair.add(p4);
	//chair.add(p5);
	//chair.add(p6);

	 var foglio=new THREE.Object3D();

  	 var te1 = THREE.ImageUtils.loadTexture("assets/textures/cruci.jpg");
     var fogli1 = new THREE.MeshPhongMaterial( {color: 0x000000});
     fogli1.map = te1;
       var grigio = new THREE.MeshLambertMaterial( { color: 0x2F2F2F, shading: THREE.FlatShading } );
    var ka = 0.4;
    grigio.ambient.setRGB( grigio.color.r * ka, grigio.color.g * ka, grigio.color.b * ka );


   var vetro = new THREE.MeshPhongMaterial( {color: 0x1c1c1c});
    vetro.transparent=true;
    vetro.opacity=0.4;
    vetro.side = THREE.DoubleSide;

   var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );

   var geometry2 = new THREE.BoxGeometry(0.6, 1, 0.002 );

   var material = new THREE.MeshLambertMaterial( {color: 0xffffff} );
   material.side = THREE.DoubleSide;

  var foglio1 = new THREE.Mesh(geometry2, fogli1);
  foglio1.rotation.x += Math.PI/2;

  plane.add(foglio1);

	foglio1.scale.set(0.2, 0.15, 0.2);
	foglio1.rotation.x += Math.PI/2;
	foglio1.position.z += 0.02;
	foglio1.position.y += 0.1;
	foglio1.position.x -= 0.1;
    var penna = new THREE.Object3D();

    var altezza = 0.3;
    var gp = new THREE.CylinderGeometry(0.01, 0.01, altezza);
    var p = new THREE.Mesh(gp, vetro);
    penna.add(p);

    var gt = new THREE.CylinderGeometry(0.01, 0.0001, 0.03);
    var c = new THREE.Mesh(gt, grigio);
    c.position.y -= altezza/2 + 0.01;
    penna.add(c);

    var cil = new THREE.CylinderGeometry(0.001, 0.001, altezza);
    var b = new THREE.Mesh(cil, grigio);
    p.add(b);

    penna.position.x += 0.5;
    penna.position.y += 0.005;
    //penna.rotation.x = Math.PI/2;
    penna.rotation.y += 1;

    foglio1.add(penna);


	chair.scale.set(1.7, 1.7, 1.3);
	
	chair.feature = this;
	chair.name = this.id;
	var model = Feature.packageModel(chair);

	return model;
};

module.exports = Tavolino;