var Feature = require('./Feature.js');

Feature.inherits(Quadrie, Feature);

function Quadrie(feature) {
	Feature.call(this, feature);
}
Quadrie.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Quadrie.prototype.in_graph = true;
Quadrie.prototype.in_2D_map = false;

Quadrie.prototype.get3DModel = function() {

var poster = new THREE.Object3D();

      var poster1 = new THREE.MeshPhongMaterial( {color: 0x000000});
      var texture = THREE.ImageUtils.loadTexture("assets/textures/poster3.jpg");
      poster1.map = texture;

      var poster2 = new THREE.MeshPhongMaterial( {color: 0x000000});
      var texture = THREE.ImageUtils.loadTexture("assets/textures/poster4.jpg");
      poster2.map = texture;

      var materiale = new THREE.MeshLambertMaterial( {color: 0xeeeeee} );

      var vet = new THREE.Mesh(new THREE.BoxGeometry(1.38, 0.9, 0.02), poster1);
     // vet.rotation.z = Math.PI/2;
      vet.position.x -= 1.37/2;
      vet.position.x -= 1;
      vet.position.x += 0.35/2 +0.01 ;
      vet.position.y += 0.01;
      vet.position.z += 0;
      poster.add(vet);

      var vet2 = new THREE.Mesh(new THREE.BoxGeometry(1.38, 0.9, 0.02), poster2);
     // vet2.rotation.z = Math.PI/2;
      vet2.position.x -= 1.37/2;
      vet2.position.x += 0.35/2 +0.01 ;
      vet2.position.x += 1.38/2 + 0.35 - 0.04;
      vet2.position.y += 0.01;
      vet2.position.z += 0;
      poster.add(vet2);

return poster;

}

module.exports = Quadrie;
