var Feature = require('./Feature.js');

Feature.inherits(Tavolo2, Feature);

function Tavolo2(feature) {
	Feature.call(this, feature);
}

Tavolo2.prototype.style = {
			    			prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
						};

Tavolo2.prototype.in_graph = true;

Tavolo2.prototype.in_2D_map = false;

Tavolo2.prototype.get3DModel = function() {
	var tavolo = new THREE.Object3D();

	var mat_bianco = new THREE.MeshPhongMaterial( {color: 0xffffff});
	var spessore = new THREE.Mesh(new THREE.BoxGeometry(2,0.5,0.1), mat_bianco);
	tavolo.add(spessore);
	tavolo.position.z+=0.7;
	tavolo.scale.set(0.85, 1, 0.8);
	return tavolo;
};

module.exports = Tavolo2;