var Feature = require('./Feature.js');

Feature.inherits(Asciugamani, Feature);

function Asciugamani(feature) {
	Feature.call(this, feature);
}
Asciugamani.prototype.style =  {
							prefix: "fa",
	    					icon: "minus",
	    					zIndex: 3
    					};

Asciugamani.prototype.in_graph = true;
Asciugamani.prototype.in_2D_map = false;

Asciugamani.prototype.get3DModel = function() {

	var maniglia = new THREE.Object3D();
      var metal = new THREE.MeshPhongMaterial( {color: 0xa8bac3} );
      var caco = new THREE.MeshPhongMaterial( {color: 0xF0E68C} ); 
      var ab = THREE.ImageUtils.loadTexture("../../assets/textures/asciuga.jpg" )
      var ae = new THREE.MeshPhongMaterial( {color: 0x000000});
      ae.map = ab;
      
      var appendino_geo = new THREE.CylinderGeometry( 0.02, 0.02,0.6 ,32);
      var braccio_geo = new THREE.CylinderGeometry( 0.015, 0.015, 0.15 ,32);

      var appendino2 = new THREE.Mesh( appendino_geo, metal ) ;
      var braccio3 = new THREE.Mesh( braccio_geo, metal ) ;
      var braccio4 = new THREE.Mesh( braccio_geo, metal ) ;

      appendino2.rotation.z-=Math.PI/2;
      appendino2.position.y+=0.15;
      appendino2.position.z+=0.45;

      braccio3.position.z+=0.45;
      braccio3.position.x+=0.25;
      braccio3.position.y+=0.1;
      braccio4.position.z+=0.45;
      braccio4.position.x-=0.25;
      braccio4.position.y+=0.1;

      maniglia.add(braccio3);
      maniglia.add(braccio4);
      maniglia.add(appendino2);

      var asciuga_geo = new THREE.BoxGeometry( 0.4, 0.5, 0.004);
      var asciuga = new THREE.Mesh( asciuga_geo, ae ) ;
      asciuga.rotation.x += Math.PI/2;
      asciuga.position.set(0, 0.125, 0.7);

      var asciuga2 = new THREE.Mesh( asciuga_geo, ae) ;
      asciuga2.rotation.x += Math.PI/2;
      asciuga2.position.set(0, 0.178, 0.7);

      var appendino_geo2 = new THREE.CylinderGeometry( 0.03, 0.03, 0.4 ,32);
      var a = new THREE.Mesh( appendino_geo2, ae ) ;
      a.rotation.z-=Math.PI/2;
      a.position.y+=0.15;
      a.position.z+=0.45;

      maniglia.add(a);
      maniglia.add(asciuga2);
      maniglia.add(asciuga);

      return maniglia;
  }


module.exports = Asciugamani;