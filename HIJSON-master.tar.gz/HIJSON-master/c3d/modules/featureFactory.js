// (1) dependencies
var utilities = require('./utilities.js');

// (2) private things
var featureClasses = {};
featureClasses['Feature'] = require('../features/Feature.js');
featureClasses['Antenna'] = require('../features/Antenna.js');
featureClasses['BadgeReader'] = require('../features/BadgeReader.js');
featureClasses['Chair'] = require('../features/Chair.js');
featureClasses['Door'] = require('../features/Door.js');
featureClasses['External_wall'] = require('../features/External_wall.js');
featureClasses['FireExtinguisher'] = require('../features/FireExtinguisher.js');
featureClasses['GraphNode'] = require('../features/GraphNode.js');
featureClasses['Hotspot'] = require('../features/Hotspot.js');
featureClasses['Internal_wall'] = require('../features/Internal_wall.js');
featureClasses['Level'] = require('../features/Level.js');
featureClasses['Light'] = require('../features/Light.js');
featureClasses['Room'] = require('../features/Room.js');
featureClasses['Server'] = require('../features/Server.js');
featureClasses['SurveillanceCamera'] = require('../features/SurveillanceCamera.js');
featureClasses['Table'] = require('../features/Table.js');
featureClasses['Window'] = require('../features/Window.js');
featureClasses['Stair'] = require('../features/Stair.js');
featureClasses['Bed'] = require('../features/Bed.js');
featureClasses['Clock'] = require('../features/Clock.js');
featureClasses['Scrivania'] = require('../features/Scrivania.js');
featureClasses['Pvc'] = require('../features/Pvc.js');
featureClasses['MuroTexture'] = require('../features/MuroTexture.js');
featureClasses['PavimentoStanze'] = require('../features/PavimentoStanze.js');
featureClasses['Porta'] = require('../features/Porta.js');
featureClasses['Finestra'] = require('../features/Finestra.js');
featureClasses['SediaScrivania'] = require('../features/SediaScrivania.js');
featureClasses['TV'] = require('../features/TV.js');
featureClasses['Letto'] = require('../features/Letto.js');
featureClasses['Wc'] = require('../features/Wc.js');
featureClasses['Lavandino'] = require('../features/Lavandino.js');
featureClasses['Asciugamani'] = require('../features/Asciugamani.js');
featureClasses['CartaIgienica'] = require('../features/CartaIgienica.js');
featureClasses['Doccia'] = require('../features/Doccia.js');
featureClasses['Armadio'] = require('../features/Armadio.js');
featureClasses['Comodino'] = require('../features/Comodino.js');
featureClasses['Controllo'] = require('../features/Controllo.js');
featureClasses['LettinoVisita'] = require('../features/LettinoVisita.js');
featureClasses['Quadri'] = require('../features/Quadri.js');
featureClasses['Quadrie'] = require('../features/Quadrie.js');
featureClasses['Poster'] = require('../features/Poster.js');
featureClasses['Telefono'] = require('../features/Telefono.js');
featureClasses['Tavolo'] = require('../features/Tavolo.js');
featureClasses['Tavolo2'] = require('../features/Tavolo2.js');
featureClasses['Secchio'] = require('../features/Secchio.js');
featureClasses['TV2'] = require('../features/TV2.js');
featureClasses['Comodino2'] = require('../features/Comodino2.js');
featureClasses['Comodino3'] = require('../features/Comodino3.js');
featureClasses['Sgabello'] = require('../features/Sgabello.js');
featureClasses['Cassetta'] = require('../features/Cassetta.js');
featureClasses['Computer'] = require('../features/Computer.js');
featureClasses['Tastiera'] = require('../features/Tastiera.js');
featureClasses['Monitor'] = require('../features/Monitor.js');
featureClasses['TV3'] = require('../features/TV3.js');
featureClasses['TV4'] = require('../features/TV4.js');
featureClasses['TV5'] = require('../features/TV5.js');
featureClasses['TV6'] = require('../features/TV6.js');
featureClasses['TV7'] = require('../features/TV7.js');
featureClasses['TV8'] = require('../features/TV8.js');
featureClasses['Tavolino'] = require('../features/Tavolino.js');
featureClasses['Fogli'] = require('../features/Fogli.js');
featureClasses['Fogli2'] = require('../features/Fogli2.js');
featureClasses['Libreria'] = require('../features/Libreria.js');
featureClasses['Libreria2'] = require('../features/Libreria2.js');
featureClasses['Bacheca'] = require('../features/Bacheca.js');



function capitaliseFirstLetter(featureClass) {
	return featureClass.charAt(0).toUpperCase() + featureClass.slice(1);
}

// (3) public/exported things
var self = module.exports = {
	generateFeature: function(feature) {
		var newFeature;
		var featureClass = capitaliseFirstLetter(feature.properties.class);
		if (featureClass in featureClasses) {
			newFeature = new featureClasses[featureClass](feature);
		} else {
			newFeature = new featureClasses['Feature'](feature);
		}
		return newFeature;
	}
}; //close module.exports